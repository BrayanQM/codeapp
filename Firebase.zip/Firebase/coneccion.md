## Conexion a Firebase (Realtime Database REST)

Proyecto: `classfirebase-d856a` (ClassFirebase)

### Que NO sirve

La "Clave Secreta" de la base de datos (`firebase.db.secret`) **ya no existe**.
Firebase elimino las *database secrets* en octubre de 2024, asi que ningun
proyecto nuevo tiene una. Ademas la base de datos del proyecto **no existia**
(todas las URLs respondian HTTP 404), por eso la app nunca se conecto y siempre
cargo el JSON local de respaldo.

### Pasos para que funcione


1. Crear la base de datos (aun no existe):
   https://console.firebase.google.com/project/classfirebase-d856a/database
   Boton **"Crear base de datos"** > elegir ubicacion > **"Modo de prueba"** > Crear

2. Copiar la URL de la pestana **Datos** y pegarla en `local.properties`:

   ```properties
   firebase.db.url=https://classfirebase-d856a-default-rtdb.firebaseio.com
   ```

   Si la BD se creo en otra region, la URL cambia, por ejemplo:
   `https://classfirebase-d856a-default-rtdb.europe-west1.firebasedatabase.app`

3. En "Modo de prueba" no hace falta token. Si mas adelante se bloquea con
   reglas, usar `firebase.db.token` con un ID token.

4. Verificar los 5 endpoints CRUD sin Postman:

   ```bash
   ./verificar-firebase.sh
   ```

### Sobre el archivo de service account

`app/classfirebase-d856a-firebase-adminsdk-fbsvc-f3e8d4ff17.json` es la cuenta
de **servidor** de Firebase. Su `private_key` concede control total del proyecto
y **nunca debe ir dentro del APK ni en el repositorio**. Por eso:

- quedo agregado al `.gitignore`
- la app **no** lo usa, la conexion es REST publica contra la base de datos
